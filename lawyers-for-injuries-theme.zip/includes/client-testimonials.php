<section class="client-testimonials" data-aos="fade-up">
	<div class="container">
		<div class="testimonial-slider-wrapper">
			<h3 class="entry-title">Client Testimonials</h3>
			<?php get_template_part('includes/testimonials-slider'); ?>
		</div>
	</div>
</section>