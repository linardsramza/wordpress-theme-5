# OTM WP Starter Theme
Wordpress starter theme adjusted for OTM's front-end developer team
